# 12: References

Haspelmath, M., Haspelmath, M., & König, E. (2020, August 9). _The converb as a cross-linguistically valid category_. \(https://www.degruyter.com/document/doi/10.1515/9783110884463-003/html?lang=en&srsltid=AfmBOopdKruiajuVkahjw-9l8BQkb2xMLbphrf7LjczBrsGdeE6xweGN)