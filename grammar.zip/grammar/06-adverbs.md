# 6: Adverbs

How does LANGNAME handle adverbs or modifying the relations or qualities of verbs? What classifications of adverbs does LANGNAME include, if any? How do different categories behave differently? Are they formed from different word classes, or are they a word class entirely of their own?