# 11: Sample Text(s)
There is no need to place any information in this section before the first sub-heading, but a brief summary of broad and unusual syntactic features could be placed here.

## 11.1 - Sample Text 1

You may, optionally, discuss the relevance of this sample text before starting it.

### 11.1.1 - Sample Text

This section should be used to present a minimum of one (1) sample text for readers of the grammar, presented in an interlinear gloss to demonstrate the structure of the language and its metalinguistic representation. The only gloss information needed here is the annotated romanization and the metalinguistic translation, though you may include other lines such as IPA or translation.

### 11.1.2 - Translation

This section should provide a readable translated version of the sample text. Note that words which are difficult or impossible to fully translate, and proper names, _might_ remain in their romanized form in this section, rather than being translated.

If you have multiple sample texts, you may present them as 11.2 and so forth, until all of your sample texts are included. Only one sample text of reasonable size is necessary for a grammar, a myth, legend, or fable are good choices for this.