# 5: Forms of Evaluation

This section before the first sub-heading, should hold a brief summary of what forms of evaluation, and how they work broadly, LANGNAME has.

## 5.1: Evaluation Form I

Describe the first evaluation form here, possibly including its own formation or structure, and its uses. Repeat this process for any other forms of evaluation.