# Dedication

_To Conlangery:_

_Without which, I would remain ignorant of so much_
