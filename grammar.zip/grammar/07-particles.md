# 07: Particles

Does LANGNAME use particles at all? If so, how pervasive are they or what functions do they fill?