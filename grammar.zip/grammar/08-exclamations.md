# 8: Exclamations

How does LANGNAME handle exclamations? Are they marked in a particular way, or do they vary from other forms of structured language? Are there themes to how different exclamations might be formed?